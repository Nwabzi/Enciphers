var ul = document.getElementById("steps"):

ul.onclick = function(event) {
    var li = event.target;
    alert(li.innerHTML);
}